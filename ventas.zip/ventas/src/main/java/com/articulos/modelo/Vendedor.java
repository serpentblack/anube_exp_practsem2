// Clase Vendedor.java
package com.articulos.modelo;

import java.util.ArrayList;
import java.util.List;

public class Vendedor {
    private String codigo;
    private String nombres;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public List<Venta> getVentas() {
        return ventas;
    }

    public void setVentas(List<Venta> ventas) {
        this.ventas = ventas;
    }

    private String apellidos;
    private String email;
    private String telefono;
    private List<Venta> ventas;

    public Vendedor(String codigo, String nombres, String apellidos, String email, String telefono) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.email = email;
        this.telefono = telefono;
        this.ventas = new ArrayList<>();
    }

    // Getters y Setters

    @Override
    public String toString() {
        return "Código: " + codigo + ", Nombres: " + nombres + ", Apellidos: " + apellidos + ", Email: " + email + ", Teléfono: " + telefono;
    }

    public void agregarVenta(int cantidadArticulos) {
        ventas.add(new Venta(cantidadArticulos));
    }

    public double calcularIngresosSemanales() {
        double ventasBrutas = 0;
        for (Venta venta : ventas) {
            ventasBrutas += venta.getCantidadArticulos();
        }
        return 200 + (0.09 * ventasBrutas);
    }
}
