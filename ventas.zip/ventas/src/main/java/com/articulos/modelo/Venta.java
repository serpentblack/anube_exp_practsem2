// Clase Venta.java
package com.articulos.modelo;

public class Venta {
    private int cantidadArticulos;

    public Venta(int cantidadArticulos) {
        this.cantidadArticulos = cantidadArticulos;
    }

    // Getters y Setters

    public int getCantidadArticulos() {
        return cantidadArticulos;
    }
}