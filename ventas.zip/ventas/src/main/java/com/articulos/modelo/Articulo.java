// Clase Articulo.java
package com.articulos.modelo;

public class Articulo {
    private int codigo;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    private String nombre;
    private double costo;
    private Categoria categoria;

    public Articulo(int codigo, String nombre, double costo, Categoria categoria) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.costo = costo;
        this.categoria = categoria;
    }

    // Getters y Setters

    @Override
    public String toString() {
        return "Código: " + codigo + ", Nombre: " + nombre + ", Costo: $" + costo + ", Categoría: " + categoria;
    }
}
