// Clase Principal.java
package com.articulos;

import com.articulos.modelo.Articulo;
import com.articulos.modelo.Categoria;
import com.articulos.modelo.Vendedor;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {
    private static List<Vendedor> vendedores = new ArrayList<>();
    private static List<Articulo> articulos = new ArrayList<>();
    private static List<Categoria> categorias = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Aquí puedes inicializar las listas de vendedores, artículos y categorías

        int opcion;
        do {
            System.out.println("Menú de opciones:");
            System.out.println("1. Gestionar vendedores");
            System.out.println("2. Gestionar artículos");
            System.out.println("3. Gestionar categorías");
            System.out.println("4. Registrar venta");
            System.out.println("5. Generar reportes");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    gestionarVendedores();
                    break;
                case 2:
                    gestionarArticulos();
                    break;
                case 3:
                    gestionarCategorias();
                    break;
                case 4:
                    registrarVenta();
                    break;
                case 5:
                    generarReportes();
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor seleccione una opción del menú.");
                    break;
            }
        } while (opcion != 6);

        scanner.close();
    }

    private static void gestionarVendedores() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Menú de opciones de gestión de vendedores:");
            System.out.println("1. Añadir vendedor");
            System.out.println("2. Eliminar vendedor");
            System.out.println("3. Modificar vendedor");
            System.out.println("4. Consultar vendedores");
            System.out.println("5. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Implementar lógica para añadir vendedor
                    break;
                case 2:
                    // Implementar lógica para eliminar vendedor
                    break;
                case 3:
                    // Implementar lógica para modificar vendedor
                    break;
                case 4:
                    // Implementar lógica para consultar vendedores
                    break;
                case 5:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor seleccione una opción del menú.");
                    break;
            }
        } while (opcion != 5);
    }

    private static void gestionarArticulos() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Menú de opciones de gestión de artículos:");
            System.out.println("1. Añadir artículo");
            System.out.println("2. Eliminar artículo");
            System.out.println("3. Modificar artículo");
            System.out.println("4. Consultar artículos");
            System.out.println("5. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Implementar lógica para añadir artículo
                    break;
                case 2:
                    // Implementar lógica para eliminar artículo
                    break;
                case 3:
                    // Implementar lógica para modificar artículo
                    break;
                case 4:
                    // Implementar lógica para consultar artículos
                    break;
                case 5:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor seleccione una opción del menú.");
                    break;
            }
        } while (opcion != 5);
    }

    private static void gestionarCategorias() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Menú de opciones de gestión de categorías:");
            System.out.println("1. Añadir categoría");
            System.out.println("2. Eliminar categoría");
            System.out.println("3. Modificar categoría");
            System.out.println("4. Consultar categorías");
            System.out.println("5. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    añadirCategoria();
                    break;
                case 2:
                    eliminarCategoria();
                    break;
                case 3:
                    modificarCategoria();
                    break;
                case 4:
                    consultarCategorias();
                    break;
                case 5:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor seleccione una opción del menú.");
                    break;
            }
        } while (opcion != 5);
    }

    private static void añadirCategoria() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Añadir categoría:");
        System.out.print("Ingrese el código de la categoría: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Ingrese el nombre de la categoría: ");
        String nombre = scanner.nextLine();

        Categoria nuevaCategoria = new Categoria(codigo, nombre);
        categorias.add(nuevaCategoria);
        System.out.println("Categoría añadida correctamente.");
    }

    private static void eliminarCategoria() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Eliminar categoría:");
        System.out.print("Ingrese el código de la categoría a eliminar: ");
        int codigo = scanner.nextInt();

        // Buscar la categoría por su código y eliminarla si existe
        boolean categoriaEncontrada = false;
        for (Categoria categoria : categorias) {
            if (categoria.getCodigo() == codigo) {
                categorias.remove(categoria);
                categoriaEncontrada = true;
                System.out.println("Categoría eliminada correctamente.");
                break; // Terminar el bucle una vez que se elimine la categoría
            }
        }

        if (!categoriaEncontrada) {
            System.out.println("No se encontró una categoría con el código especificado.");
        }
    }

    private static void modificarCategoria() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Modificar categoría:");
        System.out.print("Ingrese el código de la categoría a modificar: ");
        int codigo = scanner.nextInt();

        // Buscar la categoría por su código y modificarla si existe
        boolean categoriaEncontrada = false;
        for (Categoria categoria : categorias) {
            if (categoria.getCodigo() == codigo) {
                System.out.println("Ingrese el nuevo nombre de la categoría: ");
                String nuevoNombre = scanner.next();
                categoria.setNombre(nuevoNombre);
                categoriaEncontrada = true;
                System.out.println("Categoría modificada correctamente.");
                break; // Terminar el bucle una vez que se modifique la categoría
            }
        }

        if (!categoriaEncontrada) {
            System.out.println("No se encontró una categoría con el código especificado.");
        }
    }

    private static void consultarCategorias() {
        System.out.println("Listado de categorías:");
        for (Categoria categoria : categorias) {
            System.out.println(categoria);
        }
    }


    private static void registrarVenta() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Registrar venta:");

        // Solicitar al usuario el código del vendedor
        System.out.print("Ingrese el código del vendedor: ");
        String codigoVendedor = scanner.nextLine();

        // Buscar el vendedor por su código
        Vendedor vendedor = buscarVendedorPorCodigo(codigoVendedor);

        if (vendedor != null) {
            // Solicitar al usuario la cantidad de artículos vendidos
            System.out.print("Ingrese la cantidad de artículos vendidos: ");
            int cantidadArticulos = scanner.nextInt();

            // Registrar la venta para el vendedor
            vendedor.agregarVenta(cantidadArticulos);
            System.out.println("Venta registrada correctamente.");
        } else {
            System.out.println("No se encontró un vendedor con el código especificado.");
        }
    }

    // Método para buscar un vendedor por su código
    private static Vendedor buscarVendedorPorCodigo(String codigo) {
        for (Vendedor vendedor : vendedores) {
            if (vendedor.getCodigo().equals(codigo)) {
                return vendedor;
            }
        }
        return null; // Si no se encuentra ningún vendedor con el código especificado
    }


    private static void generarReportes() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Menú de opciones de generación de reportes:");
        System.out.println("1. Generar reporte de promedio de ventas por vendedor");
        System.out.println("2. Generar reporte general de promedio de ventas");
        System.out.println("3. Volver al menú principal");
        System.out.print("Seleccione una opción: ");
        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                generarReportePromedioVentasPorVendedor();
                break;
            case 2:
                generarReportePromedioVentasGeneral();
                break;
            case 3:
                System.out.println("Volviendo al menú principal...");
                break;
            default:
                System.out.println("Opción no válida, por favor seleccione una opción del menú.");
                break;
        }
    }

    private static void generarReportePromedioVentasPorVendedor() {
        // Implementar lógica para generar el reporte de promedio de ventas por vendedor
    }

    private static void generarReportePromedioVentasGeneral() {
        // Implementar lógica para generar el reporte general de promedio de ventas
    }

}
