// Clase Principal.java
package com.martillo.test;

import com.martillo.modelo.Producto;
import com.martillo.modelo.Venta;
import com.martillo.modelo.ProductoCantidad;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java .util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Comparator;

public class Principal {

    private static List<Producto> productos = new ArrayList<>();
    private static List<Venta> ventas = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int opcion;
        do {
            System.out.println("Menú de opciones:");
            System.out.println("1. Listar productos");
            System.out.println("2. Añadir producto");
            System.out.println("3. Ficha producto (Consultar por ID)");
            System.out.println("4. Registrar venta");
            System.out.println("5. Listado general de ventas por mes y año");
            System.out.println("6. Generar listado de ventas ordenado por número de vendedor");
            System.out.println("7. Terminar");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    listarProductos();
                    break;
                case 2:
                    añadirProducto();
                    break;
                case 3:
                    fichaProducto();
                    break;
                case 4:
                    registrarVenta();
                    break;
                case 5:
                    listarVentasPorMesYAnio();
                    break;
                case 6:
                    listarVentasOrdenadasPorVendedor();
                    break;
                case 7:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor seleccione una opción del menú.");
                    break;
            }
        } while (opcion != 7);

        scanner.close();
    }

    private static void listarProductos() {
        System.out.println("Listado de productos:");
        for (Producto producto : productos) {
            System.out.println(producto);
        }
    }

    private static void añadirProducto() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el código del producto:");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea

        System.out.println("Ingrese la descripción del producto:");
        String descripcion = scanner.nextLine();

        System.out.println("Ingrese el precio unitario del producto:");
        double precioUnitario = scanner.nextDouble();

        Producto producto = new Producto(codigo, descripcion, precioUnitario);
        productos.add(producto);

        System.out.println("Producto agregado correctamente.");
    }

    private static void fichaProducto() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el código del producto:");
        int codigo = scanner.nextInt();

        boolean encontrado = false;
        for (Producto producto : productos) {
            if (producto.getCodigo() == codigo) {
                System.out.println("Ficha del producto:");
                System.out.println(producto);
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontró ningún producto con el código ingresado.");
        }
    }


    private static void registrarVenta() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese la fecha de la venta (formato: dd/mm/yyyy):");
        String fechaStr = scanner.nextLine();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha = null;
        try {
            fecha = dateFormat.parse(fechaStr);
        } catch (ParseException e) {
            System.out.println("Error al leer la fecha. Formato incorrecto.");
            return;
        }

        System.out.println("Ingrese el número del vendedor (entre 0 y 9):");
        int numeroVendedor = scanner.nextInt();

        System.out.println("Ingrese la forma de pago (0 - Efectivo, 1 - Débito, 2 - Tarjeta):");
        int formaPago = scanner.nextInt();

        List<ProductoCantidad> productosVenta = new ArrayList<>();
        boolean agregarProducto;
        do {
            System.out.println("Ingrese el código del producto:");
            int codigo = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            Producto productoEncontrado = null;
            for (Producto producto : productos) {
                if (producto.getCodigo() == codigo) {
                    productoEncontrado = producto;
                    break;
                }
            }

            if (productoEncontrado != null) {
                System.out.println("Ingrese la cantidad vendida:");
                int cantidad = scanner.nextInt();

                ProductoCantidad productoCantidad = new ProductoCantidad(productoEncontrado, cantidad);
                productosVenta.add(productoCantidad);
            } else {
                System.out.println("No se encontró ningún producto con el código ingresado.");
            }

            System.out.println("¿Desea agregar otro producto? (true/false)");
            agregarProducto = scanner.nextBoolean();
        } while (agregarProducto);

        Venta venta = new Venta(fecha, numeroVendedor, formaPago, productosVenta);
        ventas.add(venta);

        System.out.println("Venta registrada correctamente.");
    }

    private static void listarVentasPorMesYAnio() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el mes (1-12):");
        int mes = scanner.nextInt();

        System.out.println("Ingrese el año:");
        int año = scanner.nextInt();

        System.out.println("Listado de ventas para el mes " + mes + " del año " + año + ":");
        for (Venta venta : ventas) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(venta.getFecha());
            if (cal.get(Calendar.MONTH) + 1 == mes && cal.get(Calendar.YEAR) == año) {
                System.out.println(venta);
            }
        }
    }

    private static void listarVentasOrdenadasPorVendedor() {
        Collections.sort(ventas, new Comparator<Venta>() {
            @Override
            public int compare(Venta venta1, Venta venta2) {
                return Integer.compare(venta1.getNumeroVendedor(), venta2.getNumeroVendedor());
            }
        });

        System.out.println("Listado de ventas ordenadas por número de vendedor:");
        for (Venta venta : ventas) {
            System.out.println(venta + ", Precio final: $" + calcularPrecioFinal(venta.getProductos()));
        }
    }

    private static double calcularPrecioFinal(List<ProductoCantidad> productosVenta) {
        double precioFinal = 0;
        for (ProductoCantidad productoCantidad : productosVenta) {
            precioFinal += productoCantidad.getProducto().getPrecioUnitario() * productoCantidad.getCantidad();
        }
        return precioFinal;
    }
}