// Clase Venta.java
package com.martillo.modelo;

import java.util.Date;
import java.util.List;

public class Venta {
    private Date fecha;
    private int numeroVendedor;
    private int formaPago;
    private List<ProductoCantidad> productos;

    public int getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(int formaPago) {
        this.formaPago = formaPago;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getNumeroVendedor() {
        return numeroVendedor;
    }

    public void setNumeroVendedor(int numeroVendedor) {
        this.numeroVendedor = numeroVendedor;
    }

    public List<ProductoCantidad> getProductos() {
        return productos;
    }

    public void setProductos(List<ProductoCantidad> productos) {
        this.productos = productos;
    }

    public Venta(Date fecha, int numeroVendedor, int formaPago, List<ProductoCantidad> productos) {
        this.fecha = fecha;
        this.numeroVendedor = numeroVendedor;
        this.formaPago = formaPago;
        this.productos = productos;
    }

    // Getters y Setters

    @Override
    public String toString() {
        return "Fecha: " + fecha + ", Vendedor: " + numeroVendedor + ", Forma de pago: " + formaPago;
    }
}
